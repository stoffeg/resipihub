#!/bin/bash
# Make sudo actually work
HOSTNAME=$(cat /etc/hostname)
echo "127.0.1.1 $HOSTNAME" >> /etc/hosts
hostname $HOSTNAME

if [ "$INITSYSTEM" != "on" ]; then
    /etc/init.d/ssh start
    /etc/init.d/mosquitto start
    /etc/init.d/dbus start
    hciconfig hci0 up
    /opt/dev/bin/pilexa-1.0-SNAPSHOT/util/bluetoothd -Ed
    nohup /opt/dev/bin/pilexa-1.0-SNAPSHOT/util/daemon -l -f flic.sqlite3 > /dev/console &
fi
./pilexa-1.0-SNAPSHOT/bin/pilexa > /dev/console
#/opt/dev/bin/pilexa-1.0-SNAPSHOT/bin/pilexa > /dev/console
