#!/bin/sh
/etc/init.d/ssh start
/etc/init.d/mosquitto start
/etc/init.d/dbus start
hciconfig hci0 up
/opt/dev/bin/pilexa-1.0-SNAPSHOT/util/bluetoothd -nEd &
/opt/dev/bin/pilexa-1.0-SNAPSHOT/util/daemon -l -f flic.sqlite3 &
/opt/dev/bin/pilexa-1.0-SNAPSHOT/bin/pilexa > /dev/console
