#!/bin/bash
# Make sudo actually work
HOSTNAME=$(cat /etc/hostname)
echo "127.0.1.1 $HOSTNAME" >> /etc/hosts
hostname $HOSTNAME

/etc/init.d/ssh start
/etc/init.d/mosquitto start
/etc/init.d/dbus start
hciconfig hci0 up
/etc/init.d/bluetooth stop
nohup /opt/dev/bin/pilexa-1.0-SNAPSHOT/util/bluetoothd -nEd 2>&1 > /dev/console &
echo "Starting flic daemon"
nohup /opt/dev/bin/pilexa-1.0-SNAPSHOT/util/daemon -l -f flic.sqlite3 2>&1 > /dev/console &

./pilexa-1.0-SNAPSHOT/bin/pilexa > /dev/console
#/opt/dev/bin/pilexa-1.0-SNAPSHOT/bin/pilexa > /dev/console